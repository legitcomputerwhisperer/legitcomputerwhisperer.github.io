#!/bin/sh

# Disable com.apple.atc.atwakeup

cd /System/Library/LaunchDaemons/
launchctl remove com.apple.atc.atwakeup

done

# End of script
# Coded by TheComputerWhisperer