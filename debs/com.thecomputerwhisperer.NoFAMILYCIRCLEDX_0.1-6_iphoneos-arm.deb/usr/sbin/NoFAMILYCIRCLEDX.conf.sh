#!/bin/sh

# Proactively disabling com.apple.familycircled

cd /System/Library/LaunchDaemons

launchctl disable system/com.apple.familycircled
sleep 2s
launchctl remove com.apple.familycircled

exit 0

# (C) 2016-2017 TheComputerWhisperer
