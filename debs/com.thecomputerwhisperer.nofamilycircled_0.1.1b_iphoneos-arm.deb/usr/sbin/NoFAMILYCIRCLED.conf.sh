#!/bin/sh

# Disable com.apple.familycircled

cd /System/Library/LaunchDaemons/
launchctl remove com.apple.familycircled

done

# End of script
# Coded by TheComputerWhisperer