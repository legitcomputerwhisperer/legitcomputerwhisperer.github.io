#!/bin/bash

BINGO=""
BINGO_PATH="/private/var/mobile/Containers/Data/Application/"
BINGO_REF="/private/var/tmp/SAFARI_PATH"

cd /private/var/tmp/

find /private/var/mobile/Containers/Data/Application/ -type d -name Safari > SAFARI_PATH

read -d $'\x04' BINGO < "$BINGO_REF"

IFS=/
set -- $BINGO
SAFARI_DIR=$8

rm -rf /private/var/mobile/Containers/Data/Application/$SAFARI_DIR/Library/Caches/Snapshots/com.apple.mobilesafari/*

rm -rf /private/var/tmp/SAFARI_PATH

rm -rf /private/var/mobile/Library/Caches/Ayepril_Snapshots/com.apple.mobilesafari/*
