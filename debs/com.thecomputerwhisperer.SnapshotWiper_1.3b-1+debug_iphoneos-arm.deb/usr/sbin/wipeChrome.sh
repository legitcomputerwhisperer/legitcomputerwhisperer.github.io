#!/bin/bash

BINGO=""
BINGO_PATH="/private/var/mobile/Containers/Data/Application/"
BINGO_REF="/private/var/tmp/CHROME_PATH"

cd /private/var/tmp/

find /private/var/mobile/Containers/Data/Application/ -type d -name Chromium > CHROME_PATH

read -d $'\x04' BINGO < "$BINGO_REF"

IFS=/
set -- $BINGO
CHROME_DIR=$8

rm -rf /private/var/mobile/Containers/Data/Application/$CHROME_DIR/Library/Caches/Snapshots/com.google.chrome.ios/*

rm -rf /private/var/tmp/CHROME_PATH

rm -rf /private/var/mobile/Library/Caches/Ayepril_Snapshots/com.google.chrome.ios/*
